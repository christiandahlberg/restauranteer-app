package chdah.umu.restaurantguide;

import android.location.Location;

import java.io.File;

public class Restaurant {
    private static RestaurantFactory factory;
    private String mName;
    private String mDescription;
    private File mFile;
    private Location mLocation;

    public Restaurant() {

    }

    //TEST
    public Restaurant(RestaurantFactory rFactory, String name) {
        mName = name;
        this.factory = rFactory;
        factory.addRestaurant(this);
    }

    public Restaurant(RestaurantFactory rFactory, String name, String mDescription, File mFile, Location l) {
        this.mName = name;
        this.mDescription = mDescription;
        this.mFile = mFile;
        this.mLocation = l;
        this.factory = rFactory;
        factory.addRestaurant(this);
    }

    public String getName() {
        return mName;
    }

    public void setmName(String restaurantName) {
        mName = restaurantName;
    }

    public String getmDescription() {
        return mDescription;
    }

    public void setmDescription(String description) {
        mDescription = description;
    }

    public File getFile() {
        return mFile;
    }

    public void setmFile(File file) {
        mFile = file;
    }

    public Location getmLocation() {
        return mLocation;
    }

    public void setmLocation(Location l) {
        mLocation = l;
    }

}
