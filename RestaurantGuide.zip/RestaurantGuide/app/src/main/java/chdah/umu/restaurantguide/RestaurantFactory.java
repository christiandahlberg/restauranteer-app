package chdah.umu.restaurantguide;

import java.util.ArrayList;
import java.util.List;

public class RestaurantFactory {

    private List<Restaurant> restaurants;

    public RestaurantFactory() {
        this.restaurants = new ArrayList<Restaurant>();
        // TESTDATA
        for (int i = 0; i < 30; i++) {
            Restaurant r = new Restaurant(this, "McDonalds");
        }
    }


    ///////////////////////////////////////////////////////

    /***
     * Returns all restaurants.
     * @return
     */
    public List<Restaurant> getRestaurants() {
        return restaurants;
    }

    public void setRestaurants(List<Restaurant> list) {
        restaurants = list;
    }

    public void addRestaurant(Restaurant r) {
        if (r != null) {
            restaurants.add(r);
        }
    }

    public ArrayList<String> getRestaurantNames() {
        ArrayList<String> restaurantNames = new ArrayList<>();
        for (Restaurant r : restaurants) {
            restaurantNames.add(r.getName());
        }
        return restaurantNames;
    }
}
